# 장면 1 · 새 설계 전환
# 방 탐색 → 정전 → 열린 문 → 복도 데모로 연결.

define su = Character("나", color="#a9bac2")
define seo = Character("윤서아", color="#d3bcc0")

image room = Transform("images/room_cold.png", xysize=(1920, 1080))
image black = Solid("#070b10")
image room_after = Transform(
    "images/room_cold.png",
    xysize=(1920, 1080),
    matrixcolor=SaturationMatrix(.16) * BrightnessMatrix(-.42)
)

label start:
    $ reset_scene1_state()
    $ stage = "lobby"

    # 로비는 현재의 서아를 보여 주는 짧은 프롤로그다.
    # 이후 연구소 안에서는 별도의 인물 세트를 사용한다.
    show screen memory_portrait("neutral", speaking=False)
    "조금 전, 온결 로비."
    "유리창으로 들어온 햇빛이 바닥에 길게 누워 있었다. 서아는 그 끝에 서서 내 쪽을 돌아봤다."
    "처음 만난 날에도 저렇게 소매를 조금 걷고 있었다. 봉사활동을 마치고 함께 물품 상자를 정리하던 날이었다."
    "일을 쉬기 시작한 뒤로 집에 혼자 있는 시간이 견디기 어려웠다. 잘하던 일에도 손이 붙지 않았고, 쉬면서도 쉬는 기분이 들지 않았다."
    "밖에 나갈 약속이 필요했다. 정해진 시간에 도착해서, 눈앞에 있는 일을 하나씩 끝내면 되는 곳."
    "상자를 나르고 바닥을 닦는 동안에는 내 일에 대해 생각하지 않아도 됐다. 다음 주에도 오겠다는 말이 그렇게 몇 번 쌓였다."
    "서아와는 자주 같은 일을 맡았다. 처음에는 잘 웃는 사람이라고만 생각했다."
    "웃기 전에 입술을 잠깐 다무는 버릇이 있었다. 웃음을 참는 줄 알았는데, 결국 눈가부터 풀리곤 했다. 그 표정이 예뻤다."
    "언젠가 정리를 하다가 일이 잘 안 풀린다는 말을 꺼냈다. 서아는 들고 있던 상자를 내려놓았다."
    "그 애는 내가 말을 고르는 동안에도 기다렸다. 괜찮아질 거라는 대답을 서둘러 내놓지 않았다."
    "그 뒤로는 토요일에 눈을 뜨는 일이 조금 수월해졌다."

    show screen memory_portrait("soft", speaking=True)
    seo "많이 긴장했어?"

    show screen memory_portrait("neutral", speaking=False)
    "바지 주머니에서 휴대폰을 꺼냈다가 다시 넣었다. 시간을 확인한 게 벌써 세 번째였다."
    su "조금. 이런 데는 처음이라."
    su "막상 오니까 무슨 말을 해야 할지도 모르겠고."

    show screen memory_portrait("warm", speaking=True)
    seo "지금 나한테 한 말부터 해도 되지 않을까?"

    show screen memory_portrait("neutral", speaking=False)
    "서아가 웃었다. 익숙한 웃음을 보자, 접수대 쪽으로 굳어 있던 어깨가 조금 내려갔다."
    "온결의 회복 프로그램을 처음 이야기한 것도 서아였다. 잠을 설친다는 내 말을 기억하고 있었다."
    su "이거 끝나면 좀 나아지려나."

    show screen memory_portrait("soft", speaking=True)
    seo "조금이라도 편해졌으면 좋겠어."

    show screen memory_portrait("neutral", speaking=False)
    "나는 고개를 끄덕였다. 오늘 여기까지 온 이유를 길게 설명하지 않아도 돼서 좋았다."
    su "다녀올게. 오래 걸리면 먼저 가도 돼."

    show screen memory_portrait("soft", speaking=True)
    seo "괜찮아. 여기서 기다릴게."

    show screen memory_portrait("soft", speaking=False)
    "몇 걸음 걷다가 돌아봤다. 서아가 손을 작게 흔들었다. 나도 손을 들어 보였다."

    hide screen memory_portrait
    $ stage = "intro"
    scene room

    "눈꺼풀 안쪽이 희게 번졌다. 얼굴을 돌리려다 목덜미가 당겨서 멈췄다."
    "몇 번 눈을 깜박였다. 겹쳐 보이던 천장 조명이 천천히 하나로 모였다."
    "등 아래가 단단했다. 손바닥을 밀어 넣자 차가운 소파 표면이 손끝에 닿았다."
    "잠깐, 여기가 어디야."
    "몸을 일으키자 발바닥부터 서늘해졌다. 내 방이라면 있어야 할 책상도, 커튼도 없었다."
    "낮은 탁자 위에 잔 하나가 놓여 있었다. 고개를 돌리자 벽시계와 닫힌 문이 차례로 눈에 들어왔다."
    "관자놀이를 눌렀다. 손가락이 닿은 자리보다 조금 깊은 곳이 묵직하게 욱신거렸다."
    "분명 온결 프로그램에 참가하러 왔다. 서아와 로비에 있었고, 접수를 하러 들어갔다."
    "얼마나 잔 거지. 서아가 기다리고 있을 텐데."
    "늘 휴대폰을 넣던 주머니에 손을 넣었다. 손끝에 안감만 잡혔다."
    "반대쪽도 짚었다. 주머니를 벌려 안을 들여다보고, 앉아 있던 자리를 돌아봤다."
    "떨어졌나."
    "소파 틈에 손을 밀어 넣었다. 손등이 쓸렸지만 더 깊이 더듬었다. 바닥에 무릎을 대고 아래까지 살폈다."
    "로비에서는 가지고 있었다. 시간을 확인하고 다시 넣었는데."
    "빈 주머니를 한 번 더 눌렀다. 얇은 천 너머로 손가락 모양이 그대로 느껴졌다."
    su "누가 가져간 거야?"
    "말을 뱉고 나니 방 안이 더 조용하게 느껴졌다. 나는 문 쪽으로 걸어갔다."
    "손잡이를 내리고 밀었다."
    play sound "audio/handle.wav"
    "철컥. 손잡이만 끝까지 내려갔다. 문은 틀에 붙은 채 움직이지 않았다."
    "당기는 문인가. 몸을 뒤로 기울여 당겼다. 다시 밀고, 어깨까지 댔다."
    "문에 귀를 가까이 댔다. 내 숨이 나무 표면에 부딪쳐 돌아왔다."
    "휴대폰도 없고 문도 안 열린다."
    "손잡이를 놓자 손바닥에 눌린 자국이 남았다. 숨을 길게 내쉬려 했는데 중간에 끊겼다."
    "가만히 기다릴 수는 없다. 다른 데를 보자. 나갈 방법부터 찾아야 한다."

    jump investigate

label investigate:
    $ stage = "investigation"
    window hide
    call screen investigation
    $ inspected = _return

    if inspected == "window":
        call inspect_window
    elif inspected == "cup":
        call inspect_cup
    elif inspected == "clock":
        call inspect_clock
    elif inspected == "door":
        call inspect_door
    elif inspected == "light":
        call inspect_light
    elif inspected == "panel":
        call inspect_panel
    elif inspected == "button":
        call inspect_button
    elif inspected == "drawer":
        call inspect_drawer

    if investigation_ready():
        jump blackout
    jump investigate

label inspect_window:
    "유리 앞으로 다가갔다. 눈을 가까이 댈수록 내 얼굴이 흐리게 겹쳐 보였다."
    "손으로 눈 옆을 가려 봤다. 바깥 풍경 대신 뿌연 빛만 번졌다."
    "손잡이를 찾으며 테두리를 훑었다. 손톱을 걸어 당길 만한 틈도 없었다."
    "손바닥으로 밀어 봤다. 유리는 미동도 하지 않았다."
    "창문 맞아, 이거?"
    $ add_record("window", "창", "바깥이 보이지 않는다. 열리지 않는다.")
    $ mark_observed("window")
    return

label inspect_cup:
    "잔 손잡이에 손가락을 걸었다. 몸통까지 쥐어 봤지만 온기가 없었다."
    "안쪽의 차가 작게 흔들렸다. 표면에 비친 천장 조명도 따라 흔들렸다."
    "입안이 말라 있었다. 침을 삼키자 혀뿌리가 당겼다."
    "누가 놓고 간 거지. 내가 마셨던 건가."
    "입술에 대지 않고 내려놓았다. 잔 바닥이 탁자에 닿는 소리에 어깨가 움찔했다."
    $ add_record("cup", "찻잔", "언제 놓였는지 알 수 없는 식은 차.")
    $ mark_observed("cup")
    return

label inspect_clock:
    "시계를 올려다봤다. 몇 초쯤 보고 있었을까. 초침이 같은 눈금에 붙어 있었다."
    "하나, 둘, 셋. 속으로 세면서 기다렸다."
    "움직이지 않는다."
    "괜히 귀를 기울였다. 소리라도 나면, 적어도 기다릴 이유는 생길 것 같았다."
    $ add_record("clock", "벽시계", "초침이 멎어 있다. 시간을 알 수 없다.")
    $ mark_observed("clock")
    return

label inspect_door:
    "손잡이 아래를 쓸어 봤다. 잠금을 돌리는 작은 걸쇠라도 있으면 좋겠는데, 손끝에 걸리는 게 없었다."
    play sound "audio/handle.wav"
    "손잡이를 끝까지 내린 채 천천히 당겼다. 문 가장자리에서 마른 소리가 났다."
    "힘을 풀었다가 다시 당겼다. 똑같았다."
    "안에서 여는 게 있어야 하잖아."
    "문틀과 벽이 만나는 곳까지 눈으로 더듬었다."
    $ add_record("door", "문", "손잡이는 움직이지만 문은 열리지 않는다.")
    $ mark_observed("door")
    return

label inspect_light:
    "문 위에 검은 패널이 붙어 있었다. 턱을 들자 뻣뻣해진 목 뒤가 당겼다."
    "숫자나 글씨가 뜨는 곳인가. 눈을 가늘게 뜨고 봐도 표면은 검기만 했다."
    "불이라도 들어오면 좋겠는데. 손잡이를 움직이고 다시 올려다봐도 달라지는 게 없었다."
    $ add_record("light", "문 위 패널", "검은 패널. 표시가 없다.")
    $ mark_observed("light")
    return

label inspect_panel:
    "액자 앞으로 갔다. 멀리서 놓쳤던 작은 글씨라도 찾으려고 고개를 숙였다."
    "비어 있었다. 종이 한 장 없이 테두리만 남아 있었다."
    "안내문이라도 있어야 하는 거 아닌가. 여기가 무슨 방인지, 어디로 연락하라는 건지."
    "틀 아래로 손가락을 넣었다가 뺐다. 손끝에 묻은 먼지를 엄지로 문질렀다."
    $ add_record("panel", "빈 액자", "글자 없는 액자. 안내문은 없다.")
    $ mark_observed("panel")
    return

label inspect_button:
    "버튼 앞에서 검지가 멈췄다. 문을 여는 버튼이면."
    "가장자리를 살폈다. 화살표도, 글자도 없었다."
    "누군가를 부르는 거면 어떡하지."
    "비어 있던 주머니가 떠올랐다. 이 문을 잠근 사람에게 내가 깼다고 알리는 걸까."
    "손을 내렸다. 다른 곳부터 확인하자."
    $ add_record("button", "벽 버튼", "용도를 알 수 없는 버튼. 누르지 않았다.")
    $ mark_observed("button")
    return

label inspect_drawer:
    play sound "audio/drawer.wav"
    "서랍을 당기자 걸리는 지점에서 덜컥 소리가 났다. 손을 멈추고 문 쪽을 돌아봤다."
    "잠깐 기다렸다가 안을 들여다봤다. 비어 있었다."
    "다음 칸도 열었다. 휴대폰은커녕 종이 한 장 없었다."
    "바닥을 손으로 쓸고 안쪽 모서리까지 더듬었다. 손톱 밑에 먼지만 끼었다."
    "마지막 칸을 닫으려다 다시 벌려 봤다. 아까 본 빈 바닥이 그대로였다."
    $ add_record("drawer", "서랍장", "비어 있다. 개인 물건도, 쓸 도구도 없다.")
    $ mark_observed("drawer")
    return

label blackout:
    $ stage = "blackout"
    $ checkpoint()
    "다시 방 한가운데 서 있었다. 눈길이 서랍에서 창으로, 창에서 문으로 돌아갔다."
    "한 번씩 다 봤다. 그런데 결국 같은 문 앞이다."
    "빈 주머니에 손을 넣었다 뺐다. 그만 확인해. 거기 없는 거 봤잖아."

    stop music fadeout .2
    play sound "audio/panel.wav"
    scene black
    "딱."
    "천장 조명이 꺼졌다. 방금까지 보이던 문이 어둠에 묻혔다."
    "움직이려던 발을 도로 붙였다. 눈앞에 조명의 잔상이 길게 남았다."
    "방 안을 채우던 낮은 소리도 끊겼다. 내가 삼킨 숨만 귓속에서 크게 울렸다."
    "왜 꺼졌지."

    play sound "audio/door_open.wav"
    "문 쪽에서 짧은 금속 소리가 났다. 고개가 먼저 그쪽으로 돌아갔다."

    scene room_after
    "눈앞의 잔상이 옅어지자 문 위에 가느다란 빛이 잡혔다. 그 아래로 손을 뻗었다."
    "손등이 문에 먼저 닿았다. 표면을 짚어 내려가 손잡이를 찾았다."
    play sound "audio/handle.wav"
    "천천히 내리고 당겼다. 손잡이가 내 쪽으로 따라왔다."
    play sound "audio/door_open.wav"
    "틈이 벌어졌다. 나는 팔에 힘을 준 채 그대로 멈췄다."
    "열렸다."
    "손을 놓지 않았다. 놓으면 다시 닫힐 것 같았다."

    jump leave_room

label leave_room:
    $ stage = "corridor"
    scene black
    "문틈에 얼굴을 가까이 댔다. 서늘한 공기가 뺨을 훑었다."
    "문밖은 더 어두웠다. 먼저 나가려던 발이 문턱 앞에서 멈췄다."
    play ambience "audio/corridor.wav" fadein .4
    show screen opened_door
    "바닥 가까이에 희미한 빛이 드문드문 걸려 있었다. 그 사이로 눈길을 옮겼지만 끝은 잡히지 않았다."
    "등 뒤의 방을 한 번 돌아봤다. 저 안에서 다시 문을 당기고 있을 수는 없다."
    "몸이 빠져나갈 만큼만 문을 더 당겼다. 소매가 문틀을 스쳤다."
    "손잡이를 놓고 벽을 짚었다. 우선 여기서 나가자."

    jump corridor_demo
