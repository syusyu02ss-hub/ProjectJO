# 복도 데모. 상대는 박도현이지만 수혁은 아직 이름과 얼굴을 모른다.
# 수혁은 자신의 정체를 안다. 마지막 반문은 낯선 상대에게 설명하기 전의 망설임이다.
define corridor_man = Character("어둠 속 목소리", color="#a9bac2")

image corridor_dark = Transform("images/menu_corridor.png", xysize=(1920, 1080), matrixcolor=SaturationMatrix(.12) * BrightnessMatrix(-.30))

label corridor_demo:
    $ stage = "corridor_walk"
    hide screen opened_door
    window hide
    scene black with Dissolve(.65)
    pause .6
    scene corridor_dark with Dissolve(1.4)
    play ambience "audio/corridor.wav" volume .35 fadein 1.0
    play sound "audio/steps_near.wav"
    "몇 걸음 옮기자 발밑에 걸려 있던 빛이 사라졌다. 뒤를 돌아보고 싶은 마음을 누르며 벽에 어깨를 붙였다."
    "손바닥 아래로 차가운 이음새가 지나갔다. 팔을 조금만 떼도 벽을 놓칠 것 같았다."
    "창문 하나 없는 건가. 눈에 익을 만한 모양을 찾으려 해도 어둠만 겹쳤다."
    "눈을 뜨고 있는데도 자꾸 눈꺼풀에 힘이 들어갔다. 더 크게 뜨면 뭐라도 보일 것처럼."
    "로비에는 햇빛이 들어왔었다. 지금은 밤인가. 그렇게 오래 잤나."
    "아까 시계가 몇 시였더라. 짧은 바늘이 어느 쪽에 있었는지 떠올리려다 이를 악물었다."
    "초침도 안 움직였잖아. 지금 그걸 생각해서 뭐 하게."
    play sound "audio/steps_near.wav"
    "발끝을 조금씩 밀었다. 바닥이 계속 이어지는 걸 확인한 뒤에야 뒤꿈치를 옮겼다."
    "밑창이 끌리는 소리가 복도 안쪽으로 퍼졌다. 발을 들면 덜 들릴까. 그러다 계단이라도 나오면."
    "입을 다물자 코로 새는 숨이 더 거칠게 들렸다."
    "벽에서 손을 떼면 안 된다. 손바닥이 축축해져 자꾸 옷에 닦고 싶었지만 그러지 못했다."
    "서아가 웃던 얼굴이 떠올랐다. 여기서 기다리겠다고 했었다."
    "여기라니. 그 밝은 로비? 지금도 거기 앉아 있는 거야?"
    "이런 방이 있다는 건 알았을까. 내 휴대폰이 없어지고, 문이 안 열릴 거라는 것도."
    "함께 상자를 나르던 서아의 손이 생각났다. 무거운 쪽을 잡고도 내가 놓을 때까지 기다려 주던 손이었다."
    "그 애가 일부러 그랬을 리가."
    "그런데 왜 나는 여기 있지."
    play sound "audio/steps_near.wav"
    "손끝으로 다음 이음새를 찾았다. 하나, 둘. 지나온 간격을 세었다."
    play foley "audio/steps_other.wav"
    "잠깐."
    "발을 옮기다 멈칫했다. 내 밑창이 닿기도 전에 소리가 한 번 더 났다."
    stop sound
    "발을 멈췄다."
    play foley "audio/step_last.wav"
    stop ambience fadeout .2
    # 빈 대사 한 번: 마지막 한 걸음이 잦아든 뒤 플레이어도 정적을 넘긴다.
    "{w=0.7}"
    stop foley
    window hide
    pause .6
    "내가 멈추니까."
    play foley "audio/corridor_chill.wav" volume .65
    "상대도 멈췄다."
    "누군가 있다."
    "등줄기로 식은땀이 흘렀다. 벽에 댄 손가락을 움켜쥐자 손톱이 표면을 긁었다."
    "이 소리도 들었겠지. 손에 힘을 풀었다. 손을 어디에 둬야 할지조차 신경 쓰였다."
    "메아리일 수도 있잖아. 내가 낸 소리가 돌아온 거면."
    "아니다. 마지막 한 걸음은 앞에서 났다. 내 발은 움직이지 않았다."
    "한 번만 더 걸어 봐. 어디 있는지라도 알게."
    "내 소리를 듣고 있는 거다."
    "얼마나 가까이 있지. 나를 보고 있나. 나는 아무것도 안 보이는데."
    "숨을 참았다. 목 안에서 침 넘어가는 소리만 났다. 그것까지 들렸을까."
    "방으로 돌아가야 하나. 등을 돌리는 순간 따라오면?"
    "말을 걸면 위치가 드러난다. 하지만 이미 들켰다면."
    "손에 뭘 들고 있으면 어떡하지. 팔이 닿을 만큼 가까워지고 나서야 보이면."
    "벽에 붙인 발뒤꿈치에 힘을 줬다. 도망칠 쪽과 소리가 난 쪽 사이에서 고개만 조금 움직였다."
    jump corridor_decision

label corridor_decision:
    $ stage = "corridor_choice"
    $ chapter_complete = False
    stop sound
    stop foley
    stop ambience
    scene corridor_dark
    window hide
    play ambience "audio/ticking.wav" volume .35
    call screen corridor_choices
    stop ambience
    if _return == "rush":
        jump corridor_rush
    elif _return == "flee":
        jump corridor_flee
    jump corridor_speak

label corridor_flee:
    $ stage = "corridor_flee"
    "돌아가자. 방까지는 얼마 안 왔다. 문을 닫고 버티면 된다."
    play sound "audio/steps_near.wav"
    "벽을 짚은 채 몸을 돌렸다. 서두르자 손끝이 벽의 모서리를 놓쳤다."
    "어깨가 벽에 부딪쳤다. 놀라 들이마신 숨이 목에서 걸렸다."
    stop sound
    "여기서 꺾었었나. 손을 뻗어 봤지만 벽이 계속 손바닥을 막았다. 방금 지나왔는데."
    corridor_man "거기. 멈춰."
    "바로 뒤에서 들린 것 같았다. 어깨를 돌리다가 벽에 다시 부딪쳤다."
    su "오지 마세요."
    corridor_man "안 가. 너도 갑자기 움직이지 마."
    "나는 팔을 가슴 앞으로 올렸다. 기다려도 손이 뻗쳐 오지는 않았다."
    "왼발로 바닥을 더듬다 멈췄다. 등을 돌리고 뛰기에는 목소리가 너무 가까웠다."
    jump corridor_question

label corridor_speak:
    $ stage = "corridor_speak"
    "입술을 열었다가 닫았다. 먼저 말하면 대답할까. 목소리가 들리면 방향은 잡을 수 있다."
    su "거기, 누구 있어요?"
    "첫마디가 목에 걸려 갈라졌다. 남은 말을 밀어내자 생각보다 큰 소리가 복도에 울렸다."
    corridor_man "움직이지 마."
    "생각보다 가깝다. 대답이 돌아온 쪽으로 얼굴을 돌렸다가 턱을 당겼다."
    "어깨뼈가 아플 만큼 벽에 등을 붙였다. 그 뒤로 새 발소리는 들리지 않았다."
    jump corridor_question

label corridor_question:
    $ stage = "corridor_question"
    su "누구세요?"
    "대답이 없다. 옷깃이 스치는 소리만 들렸다."
    su "거기 있는 거 알아요."
    corridor_man "그러는 넌?"
    "낮게 눌러 낸 목소리였다. 단단하게 시작한 말끝이 조금 흔들렸다."
    "잠깐 숨을 삼키는 소리가 났다."
    corridor_man "너는 누군데?"
    "이번에는 조금 더 날카로웠다. 나는 대답하려다 입을 다물었다."
    su "내가… 누구냐고?"
    # 풀버전에서는 설명할 말을 고른 뒤 온결 프로그램 참가 경위를 밝힌다.
    window hide
    stop sound
    stop foley
    stop ambience
    scene black with Dissolve(.8)
    pause 1.2
    $ chapter_complete = True
    $ stage = "demo_complete"
    call screen corridor_demo_end
    return

label corridor_rush:
    $ stage = "corridor_bad_end"
    "저쪽도 멈춰 있다. 지금 뛰면 지나칠 수 있지 않을까."
    "일단 지나가면 된다. 그 생각이 들자, 거리를 재기도 전에 몸이 앞으로 기울었다."
    play sound "audio/steps_near.wav"
    "벽에서 손을 떼고 소리가 났던 쪽으로 몸을 던졌다."
    corridor_man "오지 마!"
    "옷깃 스치는 소리가 코앞에서 났다. 너무 가깝다. 발을 멈추려 했지만 몸이 따라오지 않았다."
    stop sound
    play foley "audio/corridor_impact.wav"
    scene black
    "머리 옆으로 둔한 충격이 터졌다. 이를 맞물리는 소리가 귓속을 채웠다."
    "발을 디뎠다고 생각했다. 그런데 무릎이 먼저 바닥에 닿았다."
    "손을 뻗었다. 손잡이든 벽이든 잡히기를 바랐는데 손가락 사이로 아무것도 걸리지 않았다."
    "뺨에 차가운 바닥이 닿았다. 몸을 일으키려고 팔꿈치를 당겼다. 조금만 더."
    "한 번만 숨을."
    window hide
    stop foley fadeout .5
    pause 1.0
    call screen corridor_failure
    jump corridor_decision

screen corridor_choices():
    modal True
    vbox:
        xalign .5 yalign .55 spacing 28
        for choice_id, caption in (("flee", "도망간다"), ("speak", "먼저 말을 건다"), ("rush", "달려들어 정면 돌파한다")):
            textbutton caption:
                id ("corridor_" + choice_id)
                xsize 720
                text_xalign .5
                background Solid("#080b10e8")
                action Return(choice_id)
    key "game_menu" action ShowMenu("pause_menu")

screen corridor_failure():
    modal True
    add Solid("#000000")
    vbox:
        xalign .5 yalign .5 spacing 36
        text "어둠 속에서, 발소리가 끊겼다." xalign .5 size 36
        text "BAD END" xalign .5 size 22 color "#879299"
        textbutton "선택 직전부터 다시" id "corridor_retry" action Return() xalign .5
        textbutton "메인 메뉴" action MainMenu(confirm=False) xalign .5
    key "game_menu" action ShowMenu("pause_menu")

screen corridor_demo_end():
    modal True
    add Solid("#000000")
    vbox:
        xalign .5 yalign .5 spacing 36
        text "평온의 방" font "fonts/NanumMyeongjo.ttf" size 56 xalign .5
        text "이야기는 계속됩니다." size 30 color "#adb8be" xalign .5
        text "데모 버전은 여기까지입니다." size 23 color "#7c898f" xalign .5
        null height 24
        textbutton "메인 메뉴" id "demo_done" action MainMenu(confirm=False) xalign .5
    key "game_menu" action ShowMenu("pause_menu")
